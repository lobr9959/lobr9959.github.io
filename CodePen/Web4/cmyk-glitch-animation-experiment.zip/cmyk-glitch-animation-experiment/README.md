# CMYK Glitch Animation Experiment

A Pen created on CodePen.

Original URL: [https://codepen.io/jlengstorf/pen/PwYVyKP](https://codepen.io/jlengstorf/pen/PwYVyKP).

